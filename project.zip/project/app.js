const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require('mongoose');
const ejs = require("ejs");

//adding parentheses on date() so that the function of getDate is logged into the console.log
// console.log(date());

const app = express();
// Middleware//
app.use(express.static(__dirname + "/public"));
app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({
  extended: true
}));

const DB_URI = "mongodb+srv://user:user123@cluster0.qlwu2.mongodb.net/test?retryWrites=true&w=majority";
const mongoDB = mongoose.connect(DB_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const schema = {
  author: String,
  title: String,
  description: String,
  url: String,
  urlToImage: String,
  publishedAt: Date,
  content: String,

};

const article = mongoose.model("article", schema);


// article.find(function(err,user){
//   if(err){
//     console.log(err);
//   }else{
//     console.log(user);
//   }
// });


app.get("/",function(req,res){

  res.render("news");
});






app.listen(process.env.PORT||3000, function() {

  console.log("Server is running on 3000");
});
